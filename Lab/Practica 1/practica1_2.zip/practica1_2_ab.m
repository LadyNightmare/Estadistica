%% ESTAD�STICA . PR�CTICA 1 . EJERCICIO 2

load TempMalaga_14a

%% Apartado 1

% Los datos son TMA (1� columna: a�o, 2� col: mes, 3� col: d�a
% 4� col: temp m�xima, 5� col: temp m�nima, 6� col: temp media
% En TMA tomamos las posiciones tales que su segunda columna valga 2,
% es decir, que el mes (2� columna) sea Febrero (mes 2)

febrero = find(TMA(:,2) == 2);

% Pasamos esas posiciones a TMA, y como columna, la 5� (temp m�nimas)
% As�, min_feb ser� el vector con las temp m�nimas en febrero

min_feb = TMA(febrero, 5);

N = length(min_feb);

% Para calcular las frecuencias absolutas, usaremos un contador. 
% Como tenemos 6 intervalos, n ser� un vector de 6 elementos,
% donde cada elemento es la cantidad de temperaturas dentro del
% intervalo correspondiente. As�, si en febrero hubo 7 d�as con
% temp m�nimas entre 3 y 6 grados, el segundo intervalo (3,6] 
% tendr� 7 elementos, o sea, el segundo elemento de n ser� 7

% Inicializamos el contador, con todo a 0

n = zeros(1,6);

% Defino las temperaturas

temp = [3,6,8,10,13];

% En cada iteraci�n, a esas temperaturas les agrego la m�nima de febrero,
% y las ordeno de menor a mayor, de manera que si, por ejemplo, la m�nima
% es menor que 3, esta estar� la primera en mi vector ordenado de temperaturas

for k = 1:N
    temp_ord = sort([temp min_feb(k)]); % Ordeno las temp con mi min_feb(k)
    i = find(temp_ord == min_feb(k)); % Veo su posici�n en la lista ordenada
    % En principio se podr�a usar n(i)=..., pero si hubiera temperaturas repetidas,
    % �cu�l ser�a la nuestra? Cogemos entonces el primer i que sale, i(1).
    n(i(1)) = n(i(1)) + 1; % Uso i(1) por si hay valores repetidos
end
%�    

%% Apartado 2a

% Definimos los extremos de los intervalos (para las f�rmulas)

Li = [0 3 6 8 10 13 16];

% Igualmente, las marcas de clase (para cuando tengamos que trabajar con
% datos no agrupados

x = [1.5 4.5 7 9 11.5 14.5]; 

%! En un caso general, si tengo mis temperaturas en temp, los l�mites y 
% las marcas de clase ser�an
% Li = [2*temp(1) - temp(2), temp, 2*temp(end) - temp(end - 1)];
% x = Li(1:(end-1)) + diff(Li)/2;
%�

% Para la altura h del intervalo necesitamos la amplitud a

a = diff(Li); % Amplitud
h = n./a; % Altura = frecuencia/amplitud

% El intervalo modal es del mayor altura h. Uso [val ind] para
% obtener ind, que es la posici�n de ese intervalo modal 

[val, ind] = max(h); 

% Calculo las Deltas (diferencias de altura con los rect�ngulos 
% anterior y posterior al m�s alto)

Delta1 = h(ind) - h(ind-1);
Delta2 = h(ind) - h(ind+1);

%! Si el intervalo modal fuera extremo, para evitar el error 
% al no existir anterior o posterior, podr�amos usar
% if ind == 1
%     Delta1_gen = h(ind);
% elseif ind == length(h)
%     Delta2_gen = h(ind);
% else 
%     Delta1_gen = h(ind) - h(ind-1);
%     Delta2_gen = h(ind) - h(ind+1);
% end
%�

% Finalmente la moda, usando la f�rmula

moda = Li(ind) + a(ind) * Delta1/(Delta1 + Delta2);

% Ahora vamos "andando" por las freq acumuladas (n_acumulada, las Ni de la teor�a) 
% y buscamos la que primero se pase del valor Nc correspondiente

orden = 4;

C = zeros(1,orden - 1);

n_acumulada = cumsum(n);

Nc = N*(1:(orden-1))/orden; 

for k = 1:(orden - 1)
    i = find(Nc(k) < n_acumulada);
    if i(1) == 1
        C(k) = Li(i(1)) + a(i(1)) * Nc(k)/n(i(1));
    else
        C(k) = Li(i(1)) + a(i(1)) * (Nc(k) - n_acumulada(i(1)-1))/n(i(1));
    end
end
%�

%% Apartado 2b

% Ahora usamos las marcas de clase (x) calculadas antes

m1 = sum(n.*x)/N;  
m2 = sum(n.*x.^2)/N;
m3 = sum(n.*x.^3)/N;
m4 = sum(n.*x.^4)/N;

mu3 = m3 - 3*m2*m1 + 2*m1^3;
mu4 = m4 - 4*m3*m1 + 6*m2*m1^2 - 3*m1^4;

media = m1;
varianza = m2 - m1^2;

sesgo = mu3/sqrt(varianza)^3;
curtosis = mu4/sqrt(varianza)^4 - 3;

%% Apartado 2c

d = x - m1; % Desviaci�n

DM = sum(n.*abs(d))/N;
MCdesv = sqrt(sum(n.*d.^2)/N);

%% Apartado 3 (Datos sin agrupar)

orden = 4;

min_feb_ord = sort(min_feb);

C_sa = zeros(1,orden - 1);

Nc = N*(1:(orden-1))/orden; 

for i = 1:(orden - 1)
    if Nc(i) == floor(Nc(i))
        C_sa(i) = (min_feb_ord(Nc(i)) + min_feb_ord(Nc(i) + 1))/2;
    else
        C_sa(i) = min_feb_ord(floor(Nc(i)) + 1);
    end
end
%�

m1X = sum(x)/N;
m2X = sum(x.^2)/N;
m3X = sum(x.^3)/N;
m4X = sum(x.^4)/N;

mu3X = m3X - 3*m2X*m1X + 2*m1X^3;
mu4X = m4X - 4*m3X*m1X + 6*m2X*m1X^2 - 3*m1X^4;

mediaX = m1X;
varianzaX = m2X - m1X^2;

sesgoX = mu3X/sqrt(varianzaX)^3;
curtosisX = mu4X/sqrt(varianzaX)^4 - 3;

dX = x - m1X;
DMX = sum(abs(dX))/N;
MCdesvX = sqrt(sum(dX.^2)/N);
