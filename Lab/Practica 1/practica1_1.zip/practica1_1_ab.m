%% ESTAD�STICA . PR�CTICA 1 . EJERCICIO 1

load Datospr1_14a

%% Apartado 1

% N�mero de elementos de X

N = length(X);

% Ordenamos X 

X_ord = sort(X);

% Como calculamos cuartiles, el orden en este caso ser� 4, as�

orden = 4;

% Inicializamos el vector de los cuantiles (se guardar�n todos ah�)

C = zeros(1,orden - 1);

% Calculamos los Nc en un solo vector (para cuartiles, N*1/4, N*1/2, etc.)

Nc = N*(1:(orden-1))/orden;

% Ahora aplicamos las reglas para cuantiles de variables discretas; cada C(i) es el cuartil i-�simo 

for i = 1:(orden - 1)
    if Nc(i) == floor(Nc(i))
        C(i) = (X_ord(Nc(i)) + X_ord(Nc(i) + 1))/2;
    else
        C(i) = X_ord(floor(Nc(i)) + 1);
    end
end

% Establecemos los l�mites, en este caso, Me - 3*(Me - Q1) y Me + 3*(Q3 - Me) 

lmin = C(orden/2) - 3 * (C(orden/2) - C(1));
lmax = C(orden/2) + 3 * (C(orden - 1) - C(orden/2));

% Obtenemos las posiciones (dentro de X) de los valores "raros" y de los "normales".
% Los raros son aquellos menores que lmin o mayores que lmax

raros = find((X < lmin) | (X > lmax));
normales = find((X >= lmin) & (X <= lmax));

%! Tambi�n puede hacerse calculando los raros y entonces los "normales" son aquellos
% que no son raros
normales_alt = setdiff(1:length(X), raros)';
%�

%% Apartado 2

% La variable "normales" nos da los �ndices, es decir, las posiciones que ocupan los
% normales en X. Por lo tanto, podemos definirlos en una variable Y como sigue:

Y = X(normales);

%% Apartado 3

% Calculamos medias y varianzas de X e Y seg�n la f�rmula cl�sica

media_X = sum(X)/N;
varianza_X = sum(X.^2)/N - media_X^2;

media_Y = sum(Y)/length(Y);
varianza_Y = sum(Y.^2)/length(Y) - media_Y^2;

%! BONUS: Hagamos gr�ficas. X y los normales Y, dentro de los l�mites

plot(1:N, X, normales, Y)

% Las l�neas siguientes dibujan los l�mites lmin y lmax respectivamente

line([0,N], [lmin, lmin], 'Color', 'k', 'LineStyle', '--', 'LineWidth', 1)
line([0,N], [lmax, lmax], 'Color', 'k', 'LineStyle', '--', 'LineWidth', 1)

% X ordenados y la posici�n del primer cuantil (posici�n de Q1)
% (l�nea vertical roja) y del valor de ese cuantil (Q1) (horizontal azul).
% Obviamente han de cruzarse justo con la gr�fica de los datos ordenados (negro).

figure();
plot(1:N, X_ord, 'k')
line([0,N], [C(1),C(1)], 'Color', 'b')
line([Nc(1),Nc(1)], ylim, 'Color', 'r')

%�
